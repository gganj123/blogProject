const commentMiddleware = require("./commentMiddleware");
const postMiddleware = require("./postMiddleware");

module.exports = {
  commentMiddleware,
  postMiddleware,
};

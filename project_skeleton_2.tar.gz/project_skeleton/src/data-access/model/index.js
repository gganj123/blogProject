module.exports = {
  Comment: require("./Comment"),
  Post: require("./Post"),
};

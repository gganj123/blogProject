const commentSchema = require("./comment");
const postSchema = require("./post");

module.exports = {
  commentSchema,
  postSchema,
};

module.exports = {
  commentDAO: require("./commentDAO"),
  postDAO: require("./postDAO"),
};

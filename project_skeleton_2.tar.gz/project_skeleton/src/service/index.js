const postService = require("./postService");

module.exports = {
  postService,
};

const postController = require("./postController");

module.exports = {
  postController,
};
